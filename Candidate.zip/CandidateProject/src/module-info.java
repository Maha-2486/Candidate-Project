/**
 * 
 */
/**
 * 
 */
module CandidateProject {
	requires java.sql;
	requires java.desktop;
}