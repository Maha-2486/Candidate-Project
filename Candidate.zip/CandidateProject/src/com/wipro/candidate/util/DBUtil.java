package com.wipro.candidate.util;


import java.sql.Connection;
import java.sql.DriverManager;


public class DBUtil {
public static Connection getDBConn()
{
	Connection con = null;
	try {
	//write code here
	Class.forName("com.mysql.cj.jdbc.Driver");

    String url = "jdbc:mysql://localhost:3306/candidatedb";
    String user = "root";
    String password = "Navinya@2007";
    con = DriverManager.getConnection(url, user, password);
    } catch (Exception e) {
        e.printStackTrace();
    }
	return con;
	
	
	
    
   
	
	
	
	
}
}
