package com.wipro.candidate.service;

import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.WrongDataException;

public class CandidateMain {

    public String addCandidate(CandidateBean studBean) {
        try {
            if (studBean == null) throw new WrongDataException();
            if (studBean.getName() == null || studBean.getName().trim().isEmpty()) throw new WrongDataException();
            if (studBean.getName().length() < 2) throw new WrongDataException();
            if (studBean.getM1() < 0 || studBean.getM1() > 100 ||
                studBean.getM2() < 0 || studBean.getM2() > 100 ||
                studBean.getM3() < 0 || studBean.getM3() > 100)
                throw new WrongDataException();

            CandidateDAO dao = new CandidateDAO();
            String id = dao.generateCandidateId(studBean.getName());
            studBean.setId(id);

            int total = studBean.getM1() + studBean.getM2() + studBean.getM3();
            if (total >= 240)      { studBean.setResult("PASS"); studBean.setGrade("Distinction"); }
            else if (total >= 180) { studBean.setResult("PASS"); studBean.setGrade("First Class"); }
            else if (total >= 150) { studBean.setResult("PASS"); studBean.setGrade("Second Class"); }
            else if (total >= 105) { studBean.setResult("PASS"); studBean.setGrade("Third Class"); }
            else                   { studBean.setResult("FAIL"); studBean.setGrade("No Grade"); }

            String status = dao.addCandidate(studBean);
            if (status.equals("SUCCESS"))
                return studBean.getId() + ":" + studBean.getResult();
            else
                return "Error";

        } catch (WrongDataException e) {
            return e.toString();
        }
    }

    public ArrayList<CandidateBean> displayAll(String criteria) {
        try {
            if (!(criteria.equalsIgnoreCase("PASS") ||
                  criteria.equalsIgnoreCase("FAIL") ||
                  criteria.equalsIgnoreCase("ALL")))
                throw new WrongDataException();

            CandidateDAO dao = new CandidateDAO();
            return dao.getByResult(criteria);

        } catch (WrongDataException e) {
            return null;
        }
    }

    public static void main(String[] args) {

        CandidateMain candidateMain = new CandidateMain();

        // ---------- TEST CASE 1 ----------
        System.out.println("Test Case 1: Candidate is null");
        String result1 = candidateMain.addCandidate(null);
        System.out.println("Output: " + result1 + "\n");

        // ---------- TEST CASE 2 ----------
        System.out.println("Test Case 2: Candidate name empty");
        CandidateBean c2 = new CandidateBean();
        c2.setName("");
        c2.setM1(50); c2.setM2(60); c2.setM3(70);
        String result2 = candidateMain.addCandidate(c2);
        System.out.println("Output: " + result2 + "\n");

        // ---------- TEST CASE 3 ----------
        System.out.println("Test Case 3: Candidate name less than 2 chars");
        CandidateBean c3 = new CandidateBean();
        c3.setName("A");
        c3.setM1(80); c3.setM2(70); c3.setM3(60);
        String result3 = candidateMain.addCandidate(c3);
        System.out.println("Output: " + result3 + "\n");

        // ---------- TEST CASE 4 ----------
        System.out.println("Test Case 4: Invalid Marks");
        CandidateBean c4 = new CandidateBean();
        c4.setName("John");
        c4.setM1(120); c4.setM2(85); c4.setM3(70);
        String result4 = candidateMain.addCandidate(c4);
        System.out.println("Output: " + result4 + "\n");

        // ---------- TEST CASE 5 ----------
        System.out.println("Test Case 5: Valid Candidate - ID Generation");
        CandidateBean c5 = new CandidateBean();
        c5.setName("Jacob");
        c5.setM1(85); c5.setM2(90); c5.setM3(80);
        String result5 = candidateMain.addCandidate(c5);
        System.out.println("Output: " + result5 + "\n");

        // ---------- TEST CASE 6 ----------
        System.out.println("Test Case 6: Grade Calculation");

        CandidateBean c6a = new CandidateBean();
        c6a.setName("Ramesh");
        c6a.setM1(90); c6a.setM2(80); c6a.setM3(80); // Total=250 Distinction
        System.out.println(candidateMain.addCandidate(c6a));

        CandidateBean c6b = new CandidateBean();
        c6b.setName("Suresh");
        c6b.setM1(70); c6b.setM2(60); c6b.setM3(60); // Total=190 First Class
        System.out.println(candidateMain.addCandidate(c6b));

        CandidateBean c6c = new CandidateBean();
        c6c.setName("John");
        c6c.setM1(60); c6c.setM2(50); c6c.setM3(50); // Total=160 Second Class
        System.out.println(candidateMain.addCandidate(c6c));

        CandidateBean c6d = new CandidateBean();
        c6d.setName("David");
        c6d.setM1(40); c6d.setM2(35); c6d.setM3(35); // Total=110 Third Class
        System.out.println(candidateMain.addCandidate(c6d));

        CandidateBean c6e = new CandidateBean();
        c6e.setName("Amit");
        c6e.setM1(30); c6e.setM2(20); c6e.setM3(40); // Total=90 FAIL
        System.out.println(candidateMain.addCandidate(c6e) + "\n");

        // ---------- TEST CASE 7 ----------
        System.out.println("Test Case 7: Display by Criteria");

        System.out.println("=== PASS Candidates ===");
        ArrayList<CandidateBean> passList = candidateMain.displayAll("PASS");
        if (passList != null)
            for (CandidateBean c : passList)
                System.out.println(c.getId() + " " + c.getName() + " " + c.getResult() + " " + c.getGrade());

        System.out.println("\n=== FAIL Candidates ===");
        ArrayList<CandidateBean> failList = candidateMain.displayAll("FAIL");
        if (failList != null)
            for (CandidateBean c : failList)
                System.out.println(c.getId() + " " + c.getName() + " " + c.getResult() + " " + c.getGrade());

        System.out.println("\n=== ALL Candidates ===");
        ArrayList<CandidateBean> allList = candidateMain.displayAll("ALL");
        if (allList != null)
            for (CandidateBean c : allList)
                System.out.println(c.getId() + " " + c.getName() + " " + c.getResult() + " " + c.getGrade());

        // ---------- TEST CASE 8 ----------
        System.out.println("\nTest Case 8: Invalid criteria");
        ArrayList<CandidateBean> invalidList = candidateMain.displayAll("XYZ");
        if (invalidList == null)
            System.out.println("Output: Data Incorrect");
    }
}